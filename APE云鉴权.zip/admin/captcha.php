<?php
// 管理员后台 - 图形验证码
declare(strict_types=1);

require dirname(__DIR__) . '/core/bootstrap.php';
require_once ROOT_PATH . '/core/Security.php';

if (function_exists('client_ip') && sec_rate_hit('captcha', client_ip(), 30) > 30) {
    http_response_code(429);
    exit;
}

if (!extension_loaded('gd')) {
    header('Content-Type: image/png');
    echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==');
    exit;
}

$chars = '0123456789';
$code = '';
for ($i = 0; $i < 4; $i++) {
    $code .= $chars[random_int(0, strlen($chars) - 1)];
}
$_SESSION['captcha'] = $code;

$w = 120; $h = 40;
$img = imagecreatetruecolor($w, $h);

$bg     = imagecolorallocate($img, 247, 248, 250);
$border = imagecolorallocate($img, 229, 230, 235);
$blue   = imagecolorallocate($img, 0, 110, 255);
$gray   = imagecolorallocate($img, 78, 89, 105);
$green  = imagecolorallocate($img, 0, 180, 42);

imagefilledrectangle($img, 0, 0, $w, $h, $bg);
imagerectangle($img, 0, 0, $w - 1, $h - 1, $border);

for ($i = 0; $i < 4; $i++) {
    $c = [$blue, $gray, $green][$i % 3];
    imageline($img, random_int(0, $w), random_int(0, $h), random_int(0, $w), random_int(0, $h), $c);
}

for ($i = 0; $i < 40; $i++) {
    imagesetpixel($img, random_int(0, $w - 1), random_int(0, $h - 1), $gray);
}

$colors = [$blue, $gray, $green];
for ($i = 0; $i < 4; $i++) {
    $x = 14 + $i * 24 + random_int(-2, 2);
    $y = random_int(6, 14);
    imagechar($img, 5, $x, $y, $code[$i], $colors[$i % 3]);
}

header('Content-Type: image/png');
header('Cache-Control: no-store, no-cache, must-revalidate');
imagepng($img);
imagedestroy($img);
