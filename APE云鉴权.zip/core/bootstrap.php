<?php
// 全局引导：会话/数据库/配置/鉴权/CSRF/审计
declare(strict_types=1);

define('ROOT_PATH', dirname(__DIR__));
define('RUNTIME_PATH', ROOT_PATH . '/runtime');
define('PRODUCT_VERSION', '1.0.0');  
define('SYS_VERSION', '1.4.0');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}


function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function client_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function is_post(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function base_url(): string
{
    $https = (($_SERVER['HTTPS'] ?? '') === 'on') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    if (preg_match('#^(.*?)/(?:core|api|agent|user|plugin|install)(/.*)?$#i', $dir, $m)) {
        $dir = $m[1];
    }
    return $scheme . '://' . $host . rtrim($dir, '/') . '/';
}


function account_avatar_urls(array $acc): array
{
    $qq = preg_replace('/\D/', '', (string)($acc['qq'] ?? ''));
    if ($qq === '') {
        $prefix = explode('@', (string)($acc['email'] ?? ''))[0];
        if (preg_match('/^\d{5,12}$/', $prefix)) {
            $qq = $prefix;
        }
    }
    if ($qq === '') {
        return [];
    }
    return [
        'https://q1.qlogo.cn/g?b=qq&nk=' . $qq . '&s=100',
        'https://q2.qlogo.cn/g?b=qq&nk=' . $qq . '&s=100',
    ];
}

function avatar_img(array $acc, string $class, string $alt = ''): string
{
    $urls = account_avatar_urls($acc);
    if (!$urls) {
        return '<img class="' . e($class) . '" src="../assets/svg/mrtx.svg" alt="' . e($alt) . '">';
    }
    $first = array_shift($urls);
    $urls[] = '../assets/svg/mrtx.svg';
    return '<img class="' . e($class) . '" src="' . e($first) . '" data-fallback="' . e(json_encode($urls)) . '" alt="' . e($alt) . '" referrerpolicy="no-referrer">';
}

function avatar_fallback_script(): string
{
    return '<script>(function(){document.addEventListener("error",function(ev){var t=ev.target;if(t&&t.tagName==="IMG"&&t.dataset.fallback){try{var list=JSON.parse(t.dataset.fallback);if(list.length){t.src=list.shift();t.dataset.fallback=JSON.stringify(list);}else{t.dataset.fallback="";}}catch(e){t.dataset.fallback="";}}},true);})();</script>';
}


function config(): array
{
    static $cfg = null;
    if ($cfg === null) {
        if (!is_file(ROOT_PATH . '/config.php')) {
            http_response_code(503);
            exit('系统尚未安装，请先访问 <a href="./install/">install/</a> 完成安装。');
        }
        $cfg = require ROOT_PATH . '/config.php';
        if (!is_array($cfg)) {
            http_response_code(500);
            exit('config.php 配置格式错误。');
        }
    }
    return $cfg;
}


function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c = config()['db'];
        $dsn = "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}";
        $pdo = new PDO($dsn, $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}


function &cfg_all(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        $rows = db()->query('SELECT `cfg_key`,`cfg_value` FROM `sys_config`')->fetchAll(PDO::FETCH_KEY_PAIR);
        if ($rows !== false) {
            $cache = $rows;
        }
        require_once ROOT_PATH . '/core/PluginSys.php';
        foreach (plugin_runtime() as $pc) {
            if (isset($pc['cfg']) && is_array($pc['cfg'])) {
                foreach ($pc['cfg'] as $k => $v) {
                    if ((string)$v !== '') {
                        $cache[$k] = (string)$v;
                    }
                }
            }
        }
    }
    return $cache;
}

function cfg(string $key, string $default = ''): string
{
    $cache = cfg_all();
    return $cache[$key] ?? $default;
}

function set_cfg(string $key, string $value, string $remark = ''): void
{
    $stmt = db()->prepare('INSERT INTO `sys_config` (`cfg_key`,`cfg_value`,`remark`,`update_time`) VALUES (?,?,?,?) '
        . 'ON DUPLICATE KEY UPDATE `cfg_value`=VALUES(`cfg_value`),`update_time`=VALUES(`update_time`)');
    $stmt->execute([$key, $value, $remark, time()]);
    $cache = &cfg_all();
    $cache[$key] = (string)$value;
}


function site_info(string $key, string $default = ''): string
{
    return cfg('site_' . $key, $default);
}

function site_icon_url(string $prefix = ''): string
{
    $v = cfg('site_ico', '');
    return $v !== '' ? $v : $prefix . 'assets/svg/logo-cloud.svg';
}

function site_logo_url(string $prefix = ''): string
{
    $v = cfg('site_logo', '');
    return $v !== '' ? $v : $prefix . 'assets/svg/logo-cloud.svg';
}

function site_meta_tags(string $prefix = ''): string
{
    $html = '<link rel="icon" href="' . e(site_icon_url($prefix)) . '">' . "\n";
    $kw = trim(cfg('site_keywords', ''));
    $desc = trim(cfg('site_description', ''));
    if ($kw !== '') {
        $html .= '<meta name="keywords" content="' . e(mb_substr($kw, 0, 200)) . '">' . "\n";
    }
    if ($desc !== '') {
        $html .= '<meta name="description" content="' . e(mb_substr($desc, 0, 300)) . '">' . "\n";
    }
    return $html;
}

function site_contacts(): array
{
    return [
        'qq'       => trim(cfg('contact_qq', '')),
        'phone'    => trim(cfg('contact_phone', '')),
        'email'    => trim(cfg('contact_email', '')),
        'qq_group' => trim(cfg('contact_qq_group', '')),
    ];
}

function site_contacts_html(): string
{
    $c   = site_contacts();
    $out = [];
    if ($c['qq'] !== '') {
        $out[] = '<a class="foot-contact-item" href="https://wpa.qq.com/msgrd?v=3&site=qq&menu=yes&uin=' . e($c['qq']) . '" target="_blank" rel="noopener noreferrer">QQ：' . e($c['qq']) . '</a>';
    }
    if ($c['phone'] !== '') {
        $out[] = '<span class="foot-contact-item">手机：' . e($c['phone']) . '</span>';
    }
    if ($c['email'] !== '') {
        $out[] = '<a class="foot-contact-item" href="mailto:' . e($c['email']) . '">邮箱：' . e($c['email']) . '</a>';
    }
    if ($c['qq_group'] !== '') {
        $out[] = '<span class="foot-contact-item">QQ群：' . e($c['qq_group']) . '</span>';
    }
    return $out === [] ? '' : implode('', $out);
}

function site_icp(): string
{
    return trim(cfg('site_icp', ''));
}

function site_icp_html(): string
{
    $icp = site_icp();
    return $icp === '' ? '' : '<a class="foot-icp" href="https://beian.miit.gov.cn/" target="_blank" rel="noopener noreferrer">' . e($icp) . '</a>';
}


function audit(string $module, string $action, int $actorType, int $actorId, string $detail = ''): void
{
    try {
        $stmt = db()->prepare('INSERT INTO `audit_log` (`module`,`action`,`actor_type`,`actor_id`,`detail`,`ip`,`created_at`) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([$module, $action, $actorType, $actorId, $detail, client_ip(), time()]);
    } catch (Throwable $ex) {
        @file_put_contents(RUNTIME_PATH . '/audit_error.log', date('Y-m-d H:i:s') . ' ' . $ex->getMessage() . PHP_EOL, FILE_APPEND);
    }
}


function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    if (!isset($_POST['csrf']) || !hash_equals(csrf_token(), (string)$_POST['csrf'])) {
        http_response_code(403);
        exit('非法请求（CSRF 校验失败）');
    }
}


function json_out(int $code, string $msg = 'success', array $data = []): never
{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['code' => $code, 'msg' => $msg, 'data' => (object)$data], JSON_UNESCAPED_UNICODE);
    exit;
}


function current_admin(): ?array
{
    if (empty($_SESSION['admin_id'])) {
        return null;
    }
    static $admin = false;
    if ($admin === false) {
        $stmt = db()->prepare('SELECT `id`,`username`,`nickname`,`qq`,`email`,`status` FROM `admin` WHERE `id`=?');
        $stmt->execute([(int)$_SESSION['admin_id']]);
        $admin = $stmt->fetch() ?: null;
    }
    return ($admin && (int)$admin['status'] === 1) ? $admin : null;
}

function admin_require_login(): array
{
    $admin = current_admin();
    if (!$admin) {
        redirect('index.php');
    }
    return $admin;
}


function current_agent(): ?array
{
    if (empty($_SESSION['agent_id'])) {
        return null;
    }
    static $agent = false;
    if ($agent === false) {
        $stmt = db()->prepare('SELECT `id`,`username`,`email`,`balance`,`discount`,`level_id`,`gift_balance`,`status` FROM `agent` WHERE `id`=?');
        $stmt->execute([(int)$_SESSION['agent_id']]);
        $agent = $stmt->fetch() ?: null;
    }
    return ($agent && (int)$agent['status'] === 1) ? $agent : null;
}

function agent_require_login(): array
{
    $agent = current_agent();
    if (!$agent) {
        redirect('index.php');
    }
    return $agent;
}


function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    static $user = false;
    if ($user === false) {
        $stmt = db()->prepare('SELECT `id`,`username`,`email`,`phone`,`balance`,`real_status`,`real_name`,`status`,`agent_id` FROM `user` WHERE `id`=?');
        $stmt->execute([(int)$_SESSION['user_id']]);
        $user = $stmt->fetch() ?: null;
    }
    return ($user && (int)$user['status'] === 1) ? $user : null;
}

function user_require_login(): array
{
    $user = current_user();
    if (!$user) {
        redirect('index.php');
    }
    return $user;
}


function http_get(string $url, int $timeout = 5): string|false
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => min(3, $timeout),
        ]);
        $resp = curl_exec($ch);
        $err  = curl_errno($ch);
        curl_close($ch);
        if ($err === 0 && $resp !== false) {
            return (string)$resp;
        }
    }
    $ctx = stream_context_create(['http' => [
        'timeout'         => $timeout,
        'ignore_errors'   => true,
        'follow_location' => 1,
    ]]);
    return @file_get_contents($url, false, $ctx);
}

function http_post(string $url, string $body, array $headers = [], int $timeout = 10): string|false
{
    $headers = $headers ?: ['Content-Type: application/x-www-form-urlencoded'];
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
            CURLOPT_HTTPHEADER     => $headers,
        ]);
        $resp = curl_exec($ch);
        $err  = curl_errno($ch);
        curl_close($ch);
        if ($err === 0 && $resp !== false) {
            return (string)$resp;
        }
    }
    $ctx = stream_context_create(['http' => [
        'method'          => 'POST',
        'timeout'         => $timeout,
        'ignore_errors'   => true,
        'follow_location' => 1,
        'header'          => implode("\r\n", $headers),
        'content'         => $body,
    ]]);
    return @file_get_contents($url, false, $ctx);
}


function captcha_render(): void
{
    if (!extension_loaded('gd')) {
        header('Content-Type: image/png');
        echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==');
        exit;
    }

    $code = '';
    for ($i = 0; $i < 4; $i++) {
        $code .= (string)random_int(2, 9);
    }
    $_SESSION['captcha'] = $code;

    $w = 132; $h = 44;
    $img = imagecreatetruecolor($w, $h);

    $bg   = imagecolorallocate($img, 246, 247, 251);
    $ink  = imagecolorallocate($img, 55, 73, 106);
    $soft = imagecolorallocate($img, 213, 220, 237);
    imagefilledrectangle($img, 0, 0, $w, $h, $bg);

    imagearc($img, random_int(30, 100), random_int(10, 34), random_int(70, 110), random_int(28, 48), 0, 360, $soft);
    for ($i = 0; $i < 7; $i++) {
        imagesetpixel($img, random_int(2, $w - 3), random_int(2, $h - 3), $soft);
    }

    $fonts = [
        'C:\\Windows\\Fonts\\arialbd.ttf',
        'C:\\Windows\\Fonts\\arial.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        '/System/Library/Fonts/Helvetica.ttc',
    ];
    $font = '';
    foreach ($fonts as $f) {
        if (is_file($f)) {
            $font = $f;
            break;
        }
    }
    for ($i = 0; $i < 4; $i++) {
        $x = 18 + $i * 28;
        if ($font !== '') {
            imagettftext($img, 21, random_int(-8, 8), $x, 31 + random_int(-2, 2), $ink, $font, $code[$i]);
        } else {
            imagechar($img, 5, $x + 6, 13 + random_int(-2, 2), $code[$i], $ink);
        }
    }

    header('Content-Type: image/png');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    imagepng($img);
    imagedestroy($img);
    exit;
}


function plugin_enabled(string $code): bool
{
    require_once ROOT_PATH . '/core/PluginSys.php';
    return plugin_status_enabled($code);
}


function flash_set(string $type, string $msg): void
{
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function flash_take(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}


function invite_code_gen(): string
{
    $alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    $code = '';
    for ($i = 0; $i < 10; $i++) {
        $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    }
    return $code;
}

function invite_code_ensure(int $agentId): string
{
    if ($agentId <= 0) {
        return '';
    }
    $stmt = db()->prepare('SELECT `invite_code` FROM `agent` WHERE `id`=?');
    $stmt->execute([$agentId]);
    $code = (string)$stmt->fetchColumn();
    if ($code !== '') {
        return $code;
    }
    try {
        for ($i = 0; $i < 5; $i++) {
            $try = invite_code_gen();
            $chk = db()->prepare('SELECT `id` FROM `agent` WHERE `invite_code`=? AND `id`<>?');
            $chk->execute([$try, $agentId]);
            if (!$chk->fetch()) {
                db()->prepare('UPDATE `agent` SET `invite_code`=? WHERE `id`=?')->execute([$try, $agentId]);
                return $try;
            }
        }
    } catch (Throwable $ex) {
    }
    return '';
}

function render_pagination(int $total, int $page, int $perPage, string $baseQuery): void
{
    $pages = max(1, (int)ceil($total / $perPage));
    if ($pages <= 1) {
        return;
    }
    $page  = max(1, min($page, $pages));
    $win   = 2;     $link  = function (int $p) use ($baseQuery): string {
        return e($baseQuery . 'page=' . $p);
    };

    echo '<div class="pagination">';
    if ($page > 1) {
        echo '<a class="page-btn" href="' . $link($page - 1) . '">上一页</a>';
    } else {
        echo '<span class="page-btn disabled">上一页</span>';
    }

    $shown = [];
    for ($i = 1; $i <= $pages; $i++) {
        if ($i === 1 || $i === $pages || abs($i - $page) <= $win) {
            $shown[] = $i;
        }
    }

    $prev = 0;
    foreach ($shown as $i) {
        if ($i - $prev > 1) {
            $jump = $i > $page ? min($pages, $page + 3) : max(1, $page - 3);
            echo '<a class="page-btn" href="' . $link($jump) . '" title="跳转">...</a>';
        }
        if ($i === $page) {
            echo '<span class="page-btn active">' . $i . '</span>';
        } else {
            echo '<a class="page-btn" href="' . $link($i) . '">' . $i . '</a>';
        }
        $prev = $i;
    }

    if ($page < $pages) {
        echo '<a class="page-btn" href="' . $link($page + 1) . '">下一页</a>';
    } else {
        echo '<span class="page-btn disabled">下一页</span>';
    }
    echo '<span class="page-info">共 ' . $total . ' 条 / ' . $pages . ' 页</span>';
    echo '</div>';
}

require_once ROOT_PATH . '/core/schema_upgrade.php';
schema_upgrade_boot();
