<?php
// 极验行为验证封装
declare(strict_types=1);

function geetest_enabled(): bool
{
    return cfg('geetest_enabled', '0') === '1'
        && trim(cfg('geetest_captcha_id', '')) !== ''
        && trim(cfg('geetest_captcha_key', '')) !== '';
}

function geetest_validate(string $lotNumber, string $captchaOutput, string $passToken, string $genTime): bool
{
    $captchaId  = trim(cfg('geetest_captcha_id', ''));
    $captchaKey = trim(cfg('geetest_captcha_key', ''));
    if ($captchaId === '' || $captchaKey === ''
        || $lotNumber === '' || $captchaOutput === '' || $passToken === '' || $genTime === '') {
        return false;
    }

    $query = http_build_query([
        'lot_number'     => $lotNumber,
        'captcha_output' => $captchaOutput,
        'pass_token'     => $passToken,
        'gen_time'       => $genTime,
        'captcha_id'     => $captchaId,
        'sign_token'     => hash_hmac('sha256', $lotNumber, $captchaKey),
    ]);
    $resp = http_get('https://gcaptcha4.geetest.com/validate?' . $query, 5);
    if ($resp === false) {
        return false; 
    }
    $data = json_decode($resp, true);
    return is_array($data) && ($data['result'] ?? '') === 'success';
}
