<?php
// 首页模板 V2 插件元数据
declare(strict_types=1);

return [
    'code' => 'tpl_v2',
    'name' => 'V2 云服务官网模板',
    'cat' => 'template',
    'description' => '云服务企业级官网（腾讯云风格二创）：Hero 授权服务状态卡 + 快速查询 + 平台能力矩阵 + 三步流程 + CTA + 深色页脚。',
    'version' => '1.1.0',
    'author' => '官方内置',
    'core' => 1,
    'installable' => 1,
    'status' => 2,
    'sort' => 8,
    'config' => [],
];
