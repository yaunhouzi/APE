<?php
// 默认首页模板插件元数据
declare(strict_types=1);

return [
    'code' => 'default',
    'name' => '默认官网模板',
    'cat' => 'template',
    'description' => '简洁官方风首页：主视觉 + 域名授权查询 + 核心能力展示，站点 Logo / 联系方式自动同步。',
    'version' => '1.0.0',
    'author' => '官方内置',
    'core' => 1,
    'installable' => 1,
    'status' => 1,
    'sort' => 10,
    'config' => array (
),
];
