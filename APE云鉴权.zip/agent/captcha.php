<?php
// 代理商中心 - 图形验证码
declare(strict_types=1);
require dirname(__DIR__) . '/core/bootstrap.php';
require_once ROOT_PATH . '/core/Security.php';
config();
if (sec_rate_hit('captcha', client_ip(), 30) > 30) {
    http_response_code(429);
    exit;
}
captcha_render();
